<?php
return json_decode( '{
	"77e88891e4965161953320ec66623cbc": {
		"name": "Greg Priday",
		"email": "77e88891e4965161953320ec66623cbc",
		"loc": 27645,
		"score": 1326.0018525795194,
		"percent": 75.98178178525171
	},
	"85ce7a450a7ee4895f3bd823505e2e12": {
		"name": "adiraomj",
		"email": "85ce7a450a7ee4895f3bd823505e2e12",
		"loc": 3241,
		"score": 237.79792969852627,
		"percent": 13.626157737403693
	},
	"36639e6e074b731b093bde5a77305179": {
		"name": "Braam Genis",
		"email": "36639e6e074b731b093bde5a77305179",
		"loc": 3681,
		"score": 99.91902829067641,
		"percent": 5.725501656734132
	},
	"b7122312e4008f8f2c76911080bca01a": {
		"name": "Andrew Misplon",
		"email": "b7122312e4008f8f2c76911080bca01a",
		"loc": 1002,
		"score": 78.53122801937637,
		"percent": 4.499950448099594
	},
	"a885c7bd5442dd2acd8c3e42001332c6": {
		"name": "Alex S",
		"email": "a885c7bd5442dd2acd8c3e42001332c6",
		"loc": 31,
		"score": 2.2526365753105573,
		"percent": 0.12907926212452947
	},
	"07294cc1dd7658895e44c559dfffd76f": {
		"name": "gpriday",
		"email": "07294cc1dd7658895e44c559dfffd76f",
		"loc": 29,
		"score": 0.5107935238339003,
		"percent": 0.02926919143421009
	},
	"43c0e7220c23bd6636cf5469be6e9612": {
		"name": "Braam Genis",
		"email": "43c0e7220c23bd6636cf5469be6e9612",
		"loc": 7,
		"score": 0.1441486047750954,
		"percent": 0.0082599189521215
	}
}', true );