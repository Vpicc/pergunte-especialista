<?php
$fractions = Array(
	"abc.gif" => array("_{{f?}}^{}\\textrm{#}"),
	"frac.gif" => array("\\frac{#}{{f?}}"),
	"tfrac.gif" => array("\\tfrac{#}{{f?}}"),
	"xa.gif" => array(" #^{{f?}}"),
	"xab.gif" => array(" #_{{f?}}^{}"),
	"xa_b.gif" => array("{#_{{f?}}}^{}"),
	"xsub.gif" => array("#_{{f?}}"), 
	"sqrt.gif" => array("\\sqrt{#}"),
	"nroot.gif" => array("\\sqrt[{f?}]{#}"),
);
?>