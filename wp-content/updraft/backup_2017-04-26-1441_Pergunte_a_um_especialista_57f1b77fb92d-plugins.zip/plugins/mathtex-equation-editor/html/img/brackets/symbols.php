<?php
$brackets = Array(
	"angle.gif" => array("\\left ( # \\right )"),
	"bar.gif" => array("\\left \\| # \\right \\|"),
	"bracket.gif" => array("\\left [ # \\right ]"),
	"curlybrackets.gif" => array("\\left \\{ # \\right \\}"),
	"lceil.gif" => array("\\left \\lceil # \\right \\rceil"),
	"lfloor.gif" => array("\\left \\lfloor # \\right \\rfloor"),
	"parentheses.gif" => array("\\left ( # \\right )"),
	"twobar.gif" => array("\\left \\| # \\right \\|"),
);
?>