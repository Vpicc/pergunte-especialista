<?php
$arrows = Array(
	"leftarrow.gif" => array("\\leftarrow"),
	"leftharpoondown.gif" => array("\\leftharpoondown"),
	"leftharpoonup.gif" => array("\\leftharpoonup"),
	"leftrightarrow.gif" => array("\\leftrightarrow"),
	"leftrightharpoons.gif" => array("\\leftrightharpoons"),
	"mapsto.gif" => array("\\mapsto"),
	"oversetleftarrow.gif" => array("\\overset{a#}{\\leftarrow}"),
	"oversetright.gif" => array("\\overset{a#}{\\rightarrow}"),
	"rightarrow.gif" => array("\\rightarrow"),
	"rightharpoondown.gif" => array("\\rightharpoondown"),
	"rightharpoonup.gif" => array("\\rightharpoonup"),
	"rightleftharpoons.gif" => array("\\rightleftharpoons"),
	"to.gif" => array("\\to"),
	"uLeftarrow.gif" => array("\\Leftarrow"),
	"uLeftrightarrow.gif" => array("\\Leftrightarrow"),
	"undersetleft.gif" => array("\\undersetleft"),
	"undersetright.gif" => array("\\undersetright"),
	"uRightarrow.gif" => array("\\Rightarrow"),
	"xleftarrow.gif" => array("\\xleftarrow[a#]{b}"),
	"xrightarrow.gif" => array("\\xrightarrow[a#]{b}"),
)
?>