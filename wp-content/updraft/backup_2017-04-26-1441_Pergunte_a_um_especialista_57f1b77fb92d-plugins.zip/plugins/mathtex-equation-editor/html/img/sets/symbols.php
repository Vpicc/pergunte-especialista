<?php
$sets = Array(
		"in.gif" => array("\\in "),
		"ni.gif" => array("\\ni "),
		"notin.gif" => array("\\notin "),
		"nsubseteq.gif" => array("\\nsubseteq "),
		"nsubseteqq.gif" => array("\\nsubseteqq "),
		"nsupseteq.gif" => array("\\nsupseteq "),
		"nsupseteqq.gif" => array("\\nsupseteqq "),
		"sqsubset.gif" => array("\\sqsubset "),
		"sqsubseteq.gif" => array("\\sqsubseteq "),
		"sqsupset.gif" => array("\\sqsupset "),
		"sqsupseteq.gif" => array("\\sqsupseteq "),
		"subset.gif" => array("\\subset "), 
		"subseteq.gif" => array("\\subseteq "),
		"subseteqq.gif" => array("\\subseteqq "),
		"supset.gif" => array("\\supset "),
		"supseteq.gif" => array("\\supseteq "),
		"supseteqq.gif" => array("\\supseteqq ")
	);
?>