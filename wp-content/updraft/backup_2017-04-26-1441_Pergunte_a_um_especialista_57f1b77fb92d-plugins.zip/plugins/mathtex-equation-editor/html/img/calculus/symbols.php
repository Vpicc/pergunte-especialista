<?php
$calculus  = Array(
	"bigcap.gif" => array("\\bigcap {#}"),
	"bigcap_ab.gif" => array("\\bigcap_{{f?}}^{} #"),
	"bigcup.gif" => array("\\bigcup {#}"),
	"bigcup_ab.gif" => array("\\bigcup_{{f?}}^{} #"),
	"coprod.gif" => array("\\coprod {#}"),
	"coprod_ab.gif" => array("\\coprod_{{f?}}^{} #"),
	"iint.gif" => array("\\iint {#}"),
	"iintlimits.gif" => array("\\iint_{{f?}}^{} #"),
	"int.gif" => array("\\int {#}"),
	"intlimits.gif" => array("\\int_{{f?}}^{} #"),
	"limit.gif" => array("\\lim_{{f?}} #"),
	"oint.gif" => array("\\oint #"),
	"ointlimits.gif" => array("\\oint_{{f?}}^{} #"),
	"prod.gif" => array("\\prod {#}"),
	"prod_ab.gif" => array("\\prod_{{f?}}^{} #"),
	"sub_ab.gif" => array("\\sum_{{f?}}^{} #"),
	"sum.gif" => array("\\sum {#}"),
);
?>