<?php
$uppercase_greek = Array(
		"Delta.gif" => array("\\Delta "),
		"Gamma.gif" => array("\\Gamma "),
		"Lambda.gif" => array("\\Lambda "),
		"Omega.gif" => array("\\Omega "),
		"Phi.gif" => array("\\Phi "),
		"Pi.gif" => array("\\Pi "),
		"Psi.gif" => array("\\Psi "),
		"Sigma.gif" => array("\\Sigma "),
		"Theta.gif" => array("\\Theta "),
		"Upsilon.gif" => array("\\Upsilon "),
		"Xi.gif" => array("\\Xi ")
)
?>