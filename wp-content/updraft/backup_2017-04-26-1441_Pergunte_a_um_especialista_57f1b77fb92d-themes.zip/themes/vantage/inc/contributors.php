<?php
return json_decode( '{
	"77e88891e4965161953320ec66623cbc": {
		"name": "Greg Priday",
		"email": "77e88891e4965161953320ec66623cbc",
		"loc": 27645,
		"score": 1309.8272494877967,
		"percent": 75.90888914293139
	},
	"85ce7a450a7ee4895f3bd823505e2e12": {
		"name": "adiraomj",
		"email": "85ce7a450a7ee4895f3bd823505e2e12",
		"loc": 3241,
		"score": 234.89726521520794,
		"percent": 13.613085597487483
	},
	"36639e6e074b731b093bde5a77305179": {
		"name": "Braam Genis",
		"email": "36639e6e074b731b093bde5a77305179",
		"loc": 3681,
		"score": 98.70021359744985,
		"percent": 5.720008936508441
	},
	"b7122312e4008f8f2c76911080bca01a": {
		"name": "Andrew Misplon",
		"email": "b7122312e4008f8f2c76911080bca01a",
		"loc": 1022,
		"score": 79.2286736165132,
		"percent": 4.591567784873318
	},
	"a885c7bd5442dd2acd8c3e42001332c6": {
		"name": "Alex S",
		"email": "a885c7bd5442dd2acd8c3e42001332c6",
		"loc": 31,
		"score": 2.2251588643775726,
		"percent": 0.12895543105207166
	},
	"07294cc1dd7658895e44c559dfffd76f": {
		"name": "gpriday",
		"email": "07294cc1dd7658895e44c559dfffd76f",
		"loc": 29,
		"score": 0.5045628528330726,
		"percent": 0.029241112273640894
	},
	"43c0e7220c23bd6636cf5469be6e9612": {
		"name": "Braam Genis",
		"email": "43c0e7220c23bd6636cf5469be6e9612",
		"loc": 7,
		"score": 0.14239027695176543,
		"percent": 0.008251994873667163
	}
}', true );